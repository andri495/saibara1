<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class MasterLokasiObjek extends Model
{
    protected $table = 'master_lokasi_objek';
    protected $fillable = ['master_opd_id','nama_lokasi'];
    public function objek()
    {
        return $this->hasMany(MasterObjek::class, 'master_lokasi_id');
    }

  public function masterOpd()
    {
        return $this->belongsTo(MasterOpd::class, 'master_opd_id');
    }
}
