<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MasterRetribusi extends Model
{
    protected $table = 'master_retribusi';
    protected $fillable = ['nama_retribusi'];
    public function objek()
    {
        return $this->hasMany(MasterObjek::class, 'master_retribusi_id');
    }
}
