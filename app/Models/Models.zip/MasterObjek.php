<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;


class MasterObjek extends Model
{
    protected $table = 'master_objek';
    protected $fillable = ['master_opd_id', 'master_lokasi_id', 'uraian_objek', 'master_retribusi_id', 'master_rincian_retribusi_id', 'sub_rincian_retribusi', 'rincian_objek', 'sub_rincian_objek', 'master_role_id', 'master_satuan_id', 'master_rules_id',  'master_tpj_id', 'harga_objek', 'master_status_objek_id', 'required_document'];
    protected $with = ['lokasi', 'rules', 'opd', 'retribusi', 'rincianRetribusi', 'satuan', 'tpj', 'statusObjek', 'ratings',  'typeObject'];

    /**
     * Format the average rating to always show 1 decimal place
     * This accessor will be automatically called when accessing ratings_avg_rating_star
     */

    public function lokasi()
    {
        return $this->belongsTo(MasterLokasiObjek::class, 'master_lokasi_id');
    }
    public function rules()
    {
        return $this->belongsTo(MasterRules::class, 'master_rules_id');
    }
    public function opd()
    {
        return $this->belongsTo(MasterOpd::class, 'master_opd_id');
    }
    public function retribusi()
    {
        return $this->belongsTo(MasterRetribusi::class, 'master_retribusi_id');
    }
    public function typeObject()
    {
        return $this->belongsTo(MasterObjectType::class, 'master_type_object_id');
    }
    public function rincianRetribusi()
    {
        return $this->belongsTo(MasterRincianRetribusi::class, 'master_rincian_retribusi_id');
    }
    public function satuan()
    {
        return $this->belongsTo(MasterSatuan::class, 'master_satuan_id');
    }
    public function tpj()
    {
        return $this->belongsTo(MasterTpj::class, 'master_tpj_id');
    }
    public function statusObjek()
    {
        return $this->belongsTo(MasterStatusObjek::class, 'master_status_objek_id');
    }

    public function ratings()
    {
        return $this->hasMany(Rating::class, 'master_objek_id');
    }

    public function cartObject()
    {
        return $this->hasMany(CartObject::class, 'object_id');
    }
    public function transaksiObject()
    {
        return $this->hasMany(TransaksiObjek::class, 'object_id');
    }

    public function scopeWithTransactionCount(Builder $query)
    {
        return $query->addSelect([
            'transaction_counts' => DB::table('transaction_objects')
                ->selectRaw('COUNT(*)')
                ->whereColumn('transaction_objects.object_id', 'master_objek.id')
        ]);
    }
}
